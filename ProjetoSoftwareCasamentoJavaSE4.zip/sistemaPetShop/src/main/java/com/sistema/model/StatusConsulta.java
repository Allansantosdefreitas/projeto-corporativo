package com.sistema.model;

/**
 *
 * @author Jonathan Romualdo
 */
public enum StatusConsulta {

    MARCADA, CONSULTADA, CONCLUIDA;
    
}
