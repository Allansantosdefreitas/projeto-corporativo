package com.sistema.model;

/**
 *
 * @author Jonathan Romualdo
 */

public enum EspecialidadeFuncionario{
    
    BANHISTA, TOSADOR;
    
}
