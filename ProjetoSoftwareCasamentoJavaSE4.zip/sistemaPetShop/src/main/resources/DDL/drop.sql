DROP TABLE tb_cartao
DROP TABLE tb_consulta
DROP TABLE tb_endereco
DROP TABLE tb_exame
DROP TABLE tb_usuario
DROP TABLE tb_animal
DROP TABLE tb_servico
