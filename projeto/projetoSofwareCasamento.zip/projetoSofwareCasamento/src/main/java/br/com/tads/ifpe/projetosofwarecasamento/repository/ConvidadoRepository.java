package br.com.tads.ifpe.projetosofwarecasamento.repository;

import br.com.tads.ifpe.projetosofwarecasamento.model.Convidado;

public class ConvidadoRepository extends Repository<Convidado>{

	public ConvidadoRepository() {
		super(Convidado.class);
		}
}
