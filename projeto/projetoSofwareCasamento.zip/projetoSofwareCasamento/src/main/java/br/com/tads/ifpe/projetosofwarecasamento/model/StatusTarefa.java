package br.com.tads.ifpe.projetosofwarecasamento.model;

public enum StatusTarefa {
	CONCLUIDA, PENDENTE, CANCELADA
}
