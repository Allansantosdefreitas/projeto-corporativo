package br.com.tads.ifpe.projetosofwarecasamento.repository;

import br.com.tads.ifpe.projetosofwarecasamento.model.Casamento;

public class CasamentoRepository extends Repository<Casamento>{

	public CasamentoRepository() {
		super(Casamento.class);
	}

}
