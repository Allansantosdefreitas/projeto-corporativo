package br.com.tads.ifpe.projetosofwarecasamento.repository;

import br.com.tads.ifpe.projetosofwarecasamento.model.Convite;

public class ConviteRepository extends Repository<Convite>{

	public ConviteRepository() {
		super(Convite.class);
	}
}
