package br.com.tads.ifpe.projetosofwarecasamento.repository;

import br.com.tads.ifpe.projetosofwarecasamento.model.Conjuge;

public class ConjugeRepository extends Repository<Conjuge>{

	public ConjugeRepository() {
		super(Conjuge.class);
	}

}
