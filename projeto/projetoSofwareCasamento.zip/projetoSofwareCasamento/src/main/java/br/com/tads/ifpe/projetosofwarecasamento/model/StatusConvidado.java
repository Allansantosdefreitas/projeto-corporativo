package br.com.tads.ifpe.projetosofwarecasamento.model;

public enum StatusConvidado {
	CONFIRMADO, PENDENTE, REJEITADO
}
