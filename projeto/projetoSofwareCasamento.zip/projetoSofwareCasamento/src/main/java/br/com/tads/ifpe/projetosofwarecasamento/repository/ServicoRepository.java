package br.com.tads.ifpe.projetosofwarecasamento.repository;

import br.com.tads.ifpe.projetosofwarecasamento.model.Servico;

public class ServicoRepository extends Repository<Servico> {
	
	public ServicoRepository() {
		super(Servico.class);
	}
}
