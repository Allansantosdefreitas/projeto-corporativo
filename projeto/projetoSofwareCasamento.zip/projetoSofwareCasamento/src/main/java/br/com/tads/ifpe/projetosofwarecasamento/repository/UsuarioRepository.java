package br.com.tads.ifpe.projetosofwarecasamento.repository;

import br.com.tads.ifpe.projetosofwarecasamento.model.Usuario;

public class UsuarioRepository extends Repository<Usuario>{
	
	public UsuarioRepository() {
		super(Usuario.class);
	}
}
