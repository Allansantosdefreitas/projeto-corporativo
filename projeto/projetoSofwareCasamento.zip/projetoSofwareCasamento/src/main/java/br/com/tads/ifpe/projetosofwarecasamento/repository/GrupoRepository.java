package br.com.tads.ifpe.projetosofwarecasamento.repository;

import br.com.tads.ifpe.projetosofwarecasamento.model.Grupo;

public class GrupoRepository extends Repository<Grupo>{

	public GrupoRepository() {
		super(Grupo.class);
	}
}
