package br.com.tads.ifpe.projetosofwarecasamento.repository;

import br.com.tads.ifpe.projetosofwarecasamento.model.Tarefa;

public class TarefaRepository extends Repository<Tarefa>{

	public TarefaRepository() {
		super(Tarefa.class);
	}
}
