package br.com.tads.ifpe.projetosofwarecasamento.repository;

import br.com.tads.ifpe.projetosofwarecasamento.model.Profissional;

public class ProfissionalRepository extends Repository<Profissional>{

	public ProfissionalRepository() {
		super(Profissional.class);
	}
}
