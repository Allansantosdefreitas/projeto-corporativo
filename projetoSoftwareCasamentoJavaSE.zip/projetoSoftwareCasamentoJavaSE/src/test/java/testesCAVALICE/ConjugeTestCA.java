/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testesCAVALICE;



import br.allan.projetosoftwarecasamentojavase.*;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author Allan Santos
 * status: NOK 
 */
public class ConjugeTestCA {
     private final static EntityManagerFactory EMF = Persistence.createEntityManagerFactory("projetoSoftwareConjugePU");

    public static void main(String[] args) {

        Long idConjuge;
        Conjuge conjuge;

        try {

            // Inserir ------------------------------------            
            idConjuge = inserirConjuge();

            // Consultar ---------------------------------
            conjuge = consultarConjuge(idConjuge);

            if (conjuge != null) {
                
                // Mostra na tela
                System.out.println("Nome: " + conjuge.getNome());

                // Atualizar ------------------------------- OK
                /* Pega do banco, modifica os atributos */
                conjuge = modificarConjuge(idConjuge);
               
                /* Atualiza de fato*/
                atualizarConjuge(conjuge);
            }

            // Deletar ------------------------------------ OK
            // Só comenta esse método pra ver se o inserir e atualizar pegou :/
            //deletarConjuge(conjuge);
        } finally {
            EMF.close();
        }

    }

    public static Long inserirConjuge() {
        EntityManager em = null;
        EntityTransaction et = null;

        System.out.println("Vai setar os atts no objeto");
        Conjuge conjuge = preencherConjuge();

        try {
            em = EMF.createEntityManager();
            et = em.getTransaction();

            et.begin();
            
            em.persist(conjuge);
            
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }

        return conjuge.getIdUsuario();
    }

    private static Conjuge consultarConjuge(Long idConjuge) {

        EntityManager em = null;

        Conjuge conjugeResultado = null;

        try {
            em = EMF.createEntityManager();

            conjugeResultado = em.find(Conjuge.class, idConjuge);
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return conjugeResultado;
    }

    public static void atualizarConjuge(Conjuge conjuge) {

        EntityManager em = null;
        EntityTransaction et = null;

        try {
            em = EMF.createEntityManager();
            et = em.getTransaction();

            et.begin();
            em.merge(conjuge);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public static void deletarConjuge(Conjuge conjuge) {
        EntityManager em = null;
        EntityTransaction et = null;

        try {
            em = EMF.createEntityManager();
            et = em.getTransaction();

            Conjuge removerConjuge = em.merge(conjuge);

            et.begin();
            em.remove(removerConjuge);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }

    }

    private static Conjuge preencherConjuge() {

        // casamento
        Casamento casamento = new Casamento();
        casamento.setNome("Marriage of Dreams!");
        
        // Conjuge
        Conjuge conjuge = new Conjuge();
        conjuge.setCasamento(casamento);
        conjuge.setNome("Fulaninho");
        conjuge.setEmail("fulaninho@gmail.com");
        conjuge.setLogin("fulaninhoLogin");
        conjuge.setSenha("12345Fulaninho");
        

        return conjuge;
    }

    /* 
        Obtém a entidade do banco, modifica seus valores 
            e retorna
    */
    private static Conjuge modificarConjuge(Long idConjuge) {

        // Obtém o objeto conjuge do banco
        Conjuge conjuge;
        conjuge = consultarConjuge(idConjuge);
    
        // Conjuge
        conjuge.setNome("NEWFulaninho");
        conjuge.setEmail("NEWfulaninho@gmail.com");
        conjuge.setLogin("NEWfulaninhoLogin");
        conjuge.setSenha("NEW12345Fulaninho");
    
        return conjuge;
    }
    
    
    
}
