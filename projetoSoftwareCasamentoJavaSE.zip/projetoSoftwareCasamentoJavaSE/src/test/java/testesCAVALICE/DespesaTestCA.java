/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testesCAVALICE;

import br.allan.projetosoftwarecasamentojavase.*;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author Allan Santos 
 * status: NOT
 */
public class DespesaTestCA {

    private final static EntityManagerFactory EMF = Persistence.createEntityManagerFactory("projetoSoftwareDespesaPU");

    public static void main(String[] args) {

        Long idDespesa;
        Despesa despesa;

        try {

            // Inserir ------------------------------------            
            idDespesa = inserirDespesa();

            // Consultar ---------------------------------
            despesa = consultarDespesa(idDespesa);

            if (despesa != null) {

                // Mostra na tela
                System.out.println("Nome: " + despesa.getDespesaAtual());

                // Atualizar ------------------------------- OK
                /* Pega do banco, modifica os atributos */
                despesa = modificarDespesa(idDespesa);

                /* Atualiza de fato*/
                atualizarDespesa(despesa);
            }

            // Deletar ------------------------------------ OK
            // Só comenta esse método pra ver se o inserir e atualizar pegou :/
            //deletarDespesa(despesa);
        } finally {
            EMF.close();
        }

    }

    public static Long inserirDespesa() {
        EntityManager em = null;
        EntityTransaction et = null;

        System.out.println("Vai setar os atts no objeto");
        Despesa despesa = preencherDespesa();

        try {
            em = EMF.createEntityManager();
            et = em.getTransaction();

            et.begin();
            em.persist(despesa);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }

        return despesa.getIdDespesa();
    }

    private static Despesa consultarDespesa(Long idDespesa) {

        EntityManager em = null;

        Despesa despesaResultado = null;

        try {
            em = EMF.createEntityManager();

            despesaResultado = em.find(Despesa.class, idDespesa);
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return despesaResultado;
    }

    public static void atualizarDespesa(Despesa despesa) {

        EntityManager em = null;
        EntityTransaction et = null;

        try {
            em = EMF.createEntityManager();
            et = em.getTransaction();

            et.begin();
            em.merge(despesa);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public static void deletarDespesa(Despesa despesa) {
        EntityManager em = null;
        EntityTransaction et = null;

        try {
            em = EMF.createEntityManager();
            et = em.getTransaction();

            Despesa removerDespesa = em.merge(despesa);

            et.begin();
            em.remove(removerDespesa);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }

    }

    private static Despesa preencherDespesa() {

        // Preenchendo attrs
        Despesa despesa = new Despesa();
        
        // Casamento
        Casamento casamento = new Casamento();
        despesa.setCasamento(casamento);
        
        // Despesa
        despesa.setDespesaPrevista(20.000);
        despesa.setDespesaAtual(10.000);
        despesa.setValorRestante(10.000);
        
      
        return despesa;
    }

    /* 
        Obtém a entidade do banco, modifica seus valores 
            e retorna
     */
    private static Despesa modificarDespesa(Long idDespesa) {

        // Obtém o objeto despesa do banco
        Despesa despesa;
        despesa = consultarDespesa(idDespesa);

        // Despesa
        despesa.setDespesaPrevista(00.000);
        despesa.setDespesaAtual(00.000);
        despesa.setValorRestante(00.000);
        
        return despesa;
    }
}
