package testesCAVALICE;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



import br.allan.projetosoftwarecasamentojavase.*;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author Allan Santos
 * status: OK
 */
public class CasamentoTestCA {

    private final static EntityManagerFactory EMF = Persistence.createEntityManagerFactory("projetoSoftwareCasamentoPU");

    public static void main(String[] args) {

        Long idCasamento;
        Casamento casamento;

        try {

            // Inserir ------------------------------------            
            idCasamento = inserirCasamento();

            // Consultar ---------------------------------
            casamento = consultarCasamento(idCasamento);

            if (casamento != null) {
                
                // Mostra na tela
                System.out.println("Nome: " + casamento.getNome());

                // Atualizar ------------------------------- OK
                /* Pega do banco, modifica os atributos */
                casamento = modificarCasamento(idCasamento);
               
                /* Atualiza de fato*/
                atualizarCasamento(casamento);
            }

            // Deletar ------------------------------------ OK
            // Só comenta esse método pra ver se o inserir e atualizar pegou :/
            deletarCasamento(casamento);
        } finally {
            EMF.close();
        }

    }

    public static Long inserirCasamento() {
        EntityManager em = null;
        EntityTransaction et = null;

        System.out.println("Vai setar os atts no objeto");
        Casamento casamento = new Casamento();
        
        casamento = preencherCasamento();

        try {
            em = EMF.createEntityManager();
            et = em.getTransaction();

            et.begin();
            em.persist(casamento);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }

        return casamento.getIdCasamento();
    }

    private static Casamento consultarCasamento(Long idCasamento) {

        EntityManager em = null;

        Casamento casamentoResultado = null;

        try {
            em = EMF.createEntityManager();

            casamentoResultado = em.find(Casamento.class, idCasamento);
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return casamentoResultado;
    }

    public static void atualizarCasamento(Casamento casamento) {

        EntityManager em = null;
        EntityTransaction et = null;

        try {
            em = EMF.createEntityManager();
            et = em.getTransaction();

            et.begin();
            em.merge(casamento);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public static void deletarCasamento(Casamento casamento) {
        EntityManager em = null;
        EntityTransaction et = null;

        try {
            em = EMF.createEntityManager();
            et = em.getTransaction();

            Casamento removerCasamento = em.merge(casamento);

            et.begin();
            em.remove(removerCasamento);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }

    }

    private static Casamento preencherCasamento() {

        // Preenchendo attrs
        Casamento casamento = new Casamento();
        casamento.setNome("Marriage of Dreams");

        return casamento;
    }

    /* 
        Obtém a entidade do banco, modifica seus valores 
            e retorna
    */
    private static Casamento modificarCasamento(Long idCasamento) {

        // Obtém o objeto casamento do banco
        Casamento casamento;
        casamento = consultarCasamento(idCasamento);

        // Muda os valores dos seus atributos
        casamento.setNome("Marriage of OUR Dreams!");

        return casamento;
    }

}
