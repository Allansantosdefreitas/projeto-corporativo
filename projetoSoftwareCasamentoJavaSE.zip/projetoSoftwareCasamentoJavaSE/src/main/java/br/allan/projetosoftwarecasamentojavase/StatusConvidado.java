package br.allan.projetosoftwarecasamentojavase;

public enum StatusConvidado {
	CONFIRMADO, PENDENTE, REJEITADO
}
