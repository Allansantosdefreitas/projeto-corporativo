package br.allan.projetosoftwarecasamentojavase;

public enum StatusTarefa {
	CONCLUIDA, PENDENTE, CANCELADA
}
